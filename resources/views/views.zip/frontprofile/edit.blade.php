@extends('front_jobs.app_one_wrapper')
@section('title') 	
	<title>Profile | Skill Link </title>
@endsection 
@section('header')  
	@include('dashboard_layouts.headermenu')   
	<header class="header-responsive"> 
		<div class="container-fluid">
			<div class="back-responsive">
				<a onclick="goBack()"> 
					<img src="{{ asset('dashboard_assets/images/icon/left.png') }}" alt="">
				</a>
			</div>
			<div class="navbar-sl">
				<h4 class="yellow" style="margin:15px 15px;">Edit Profile</h4>
			</div>
			 
		</div>
</header> 
@endsection 
@section('content')   
	<div class="row">
		<div class="col-md-9">
			<div class="alert bg-orange" id="myAlert" style="padding: 10px 10px 5px 10px;">
			    <div class="row">
			    	<div class="col-xs-8 col-sm-9 col-md-11">
			    		<p style="margin-top: 5px;">Share Profile Change</p>
			    	</div>
			    	<div class="col-xs-4 col-sm-3 col-md-1">
			    		<label class="switch">
						  <input type="checkbox" class="switch-input">
						  <span class="slider round"></span>
						</label>
			    	</div>
			    </div>
			</div>
			<div class="wrapper" style="margin-bottom: 20px;">
				<div class="bg-cover">
					<img src="assets/images/bg_1.jpg" alt="">
					<div class="bg-cover-hover">
						<input type="file">
					</div>
				</div>
				<div style="position: relative;">
					<div class="branch-img branch-profile">
						<img src="assets/images/2.jpg" alt="">
						<div class="branch-img-hover">
							<input type="file"">
						</div>
						<div class="branch-check branch-img-status">
							<img src="assets/images/check.png" alt="">
						</div><br><br>
				</div>
				<div class="row">
					<div class="col-md-4">
						<div class="box border-all-radius" style="margin-bottom: 15px;">
							<div class="box-header with-border">
								<span class="box-title"><b>Employment Status</b></span>
							</div>
							<select name="" id="" class="form-control">
								<option value="">Select Employment</option>
								<option value="">Satisfied Currently</option>
								<option value="">Passively Looking</option>
								<option value="">Actively Looking</option>
							</select>
						</div>
					</div>
					<div class="col-md-8">
						<div class="box margin-responsive-15 border-all-radius">
							<div class="box-header with-border">
								<span class="box-title"><b>Personal Info</b></span>
							</div>
							<div class="box-body" id="table-info">
								<table class="table">
									<tbody>
										<tr>
											<td>First Name</td>
											<td><b><input type="text" value="Indra" class="form-control"></b></td>
										</tr>
										<tr>
											<td>Middle Name</td>
											<td><b><input type="text" value="Harta" class="form-control"></b></td>
										</tr>
										<tr>
											<td>Last Name</td>
											<td><b><input type="text" value="Kenda" class="form-control"></b></td>
										</tr>
										<tr>
											<td>About Me</td>
											<td><b><input type="text" value="Father, Husband" class="form-control"></b></td>
										</tr>
										<tr>
											<td>Birthday</td>
											<td><b><input type="text" value="September, 24, 1989" class="form-control"></b></td>
										</tr>
										<tr>
											<td>Lives in</td>
											<td><b><input type="text" value="Edmonton, Canada" class="form-control"></b></td>
										</tr>
										<tr>
											<td>Occupation</td>
											<td><b><input type="text" value="Pipefilter" class="form-control"></b></td>
										</tr>
										<tr>
											<td>Joined</td>
											<td><b><input type="text" value="January 8, 2017" class="form-control"></b></td>
										</tr>
										<tr>
											<td>Gender</td>
											<td><b><input type="text" value="Male" class="form-control" disabled=""></b></td>
										</tr>
										<tr>
											<td>Status</td>
											<td><b><input type="text" value="Married" class="form-control" disabled=""></b></td>
										</tr>
										<tr>
											<td>Email</td>
											<td><b><input type="text" value="indrahrta@gmail.com" class="form-control"></b></td>
										</tr>
										<tr>
											<td>Website</td>
											<td><b><input type="text" value="indra.com" class="form-control"></b></td>
										</tr>
										<tr>
											<td>Phone Number</td>
											<td><b><input type="number" value="02121823819" class="form-control"></b></td>
										</tr>
										<tr>
											<td>Social Network</td>
											<td>
												<div class="row" style="margin-bottom: 20px;">
													<div class="col-xs-3 col-sm-2 col-md-1">
														<span class="btn btn-warning"><i class="fa fa-facebook"></i></span>
													</div>
													<div class="col-xs-9 col-sm-10 col-md-11">
														<input type="text" value="lorem" class="form-control">
													</div>
												</div>
												<div class="row" style="margin-bottom: 20px;">
													<div class="col-xs-3 col-sm-2 col-md-1">
														<span class="btn btn-warning"><i class="fa fa-twitter"></i></span>
													</div>
													<div class="col-xs-9 col-sm-10 col-md-11">
														<input type="text" value="lorem" class="form-control">
													</div>
												</div>
												<div class="row">
													<div class="col-xs-3 col-sm-2 col-md-1">
														<span class="btn btn-warning"><i class="fa fa-instagram"></i></span>
													</div>
													<div class="col-xs-9 col-sm-10 col-md-11">
														<input type="text" value="lorem" class="form-control">
													</div>
												</div>
											</td>
										</tr>
									</tbody>
								</table>
								<div class="pull-right">
									<button class="btn bg-yellow">Save Change</button>
								</div>
								<div class="clearfix"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
@endsection

@section('script')  
@endsection
