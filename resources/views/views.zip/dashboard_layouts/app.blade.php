<!DOCTYPE html> 
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="user-scalable=no, width=device-width, maximum-scale=1.0">
		<meta name="csrf-token" content="{{ csrf_token() }}">
		@yield('title')
		 <link href="{!! asset('landing_page/image/20171206_211142.png') !!}" rel="shortcut icon">
		<link rel="stylesheet" href="{{ asset('dashboard_assets/css/bootstrap.min.css') }}	">
		<link rel="stylesheet" href="{{ asset('dashboard_assets/css/font-awesome.min.css') }}">
		<link rel="stylesheet" href="{{ asset('dashboard_assets/css/style.css') }}">
		 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">  
		  {{ Html::style('css/sweetalert.min.css')}}  
		@yield('style')
	</head>
	<body>
		<div class="wrapper"> 
			@include('dashboard_layouts.header') 
			@include('dashboard_layouts.midcontent') 
			<div class="main-wrapper" id="wrapper">
				<div class="row">
					@yield('content') 
					@include('dashboard_layouts.right')
				</div>
			</div>
		</div>
		
		<script src="{{ asset('dashboard_assets/js/jquery.min.js') }}"></script>
		<script src="{{ asset('dashboard_assets/js/bootstrap.min.js') }}"></script> 
		<script src="{{ asset('js/view.js') }}"></script>
		<script src="{{ asset('js/jquery.jscroll.js') }}"></script> 
		<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
		{{ Html::script('js/sweetalert.min.js')}}  
		@include('sweet::alert')
		@yield('script') 
		<script type="text/javascript">

			$('ul.pagination').hide();
		    $(function() {
		        $('.infinite-scroll').jscroll({
		            autoTrigger: true,
		            loadingHtml: '<div class="spinner"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div>',
		            padding: 0,
		            nextSelector: '.pagination li.active + li a',
		            contentSelector: 'div.infinite-scroll',
		            callback: function() {
		                $('ul.pagination').remove();
		            }
		        });
		    });  
		    
			$.ajaxSetup({
			    headers: {
			        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			    }
			});
			$('[data-toggle="expand"]').click(function(ev) {
				ev.preventDefault();
				$($(this).attr('data-target')).toggleClass('expand');
			});

			$('[data-toggle="user-menu"]').click(function(ev) {
				ev.preventDefault();
				ev.stopPropagation();
				$(this).next($(this).attr('data-target')).toggleClass('in');
			});

			$('#user-menu').click(function(ev) {
				ev.stopPropagation();
			});

			$(document).click(function(ev) {
				$('#user-menu').removeClass('in');
			});

			$(document).ready(function(){
			    $(".close").click(function(){
			        $("#myAlert").alert("close");
			    });
			});	
		</script>

			<script type="text/javascript">	
			function follow(i) {
				id = $(i).data('id');  
	                $.ajax({
	                    type: 'POST',
	                    url: "{{ route('follow') }}",
	                    data: {
	                        '_token': $('input[name=_token]').val(),
	                        'id': id
	                    },
	                    success: function(data) { 
	                        if ((data.errors)) {
			                        setTimeout(function () { 
			                            toastr.error('Validation error!', 'Error Alert', {timeOut: 1000});
			                        }, 500);  
			                } else {
			                	toastr.success('User Followed', 'Success Alert', {timeOut: 5000}); 
		                        location.reload(); 
			                }
	                    },
	                });
			} 	
			</script>
		
	</body>
</html>
