<div class="col-md-3">
	<div class="box margin-15-responsive">
		<span class="box-title"><b>Trending Right Now</b></span>
		<div class="box-body margin-15">

			@foreach ($trending as $trend)
				<div class="trending-content">
					@if (count($trend->images_post) == 0)
						<img src="{{ asset('dashboard_assets/images/bg_1.jpg') }}" alt="">
					@else 
						<img src="{{ asset('post_image/'.$trend->images_post->image) }}" alt="">
					@endif
					<div class="trending-title bg-blue-dark">
						<a href="{{ route('post_detail',array('detail'=>$trend->id)) }}">{{ str_limit($trend->post,15)  }}</a>
					</div>
				</div> 
			@endforeach
			
		</div>
		<div class="bg-blue-dark" style="height: 300px;padding: 5px 15px;">
			<h1 style="color: #fff;">ads</h1>
		</div>
	</div>
</div>