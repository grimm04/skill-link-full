<header class="header-responsive">
	<div class="container-fluid">
		<div class="back-responsive">
			<img src="{{ asset('dashboard_assets/images/icon/left.png') }}" alt="">
		</div>
		<div class="navbar-sl">
			<h4 class="yellow" style="margin:15px 15px;">Job Setting</h4>
		</div>
	</div>
</header>