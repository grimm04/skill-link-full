<ul>
	<li><a href="{{ route('dashboard') }}" class="{{ set_active('dashboard') }}"> 
		@if (set_active('dashboard'))
			<img src="{{ asset('dashboard_assets/images/icon/feed-grey.png') }}" alt="">
		@else
			<img src="{{ asset('dashboard_assets/images/icon/feed.png') }}" alt="">
		@endif
		</a></li>
	<li><a href="{{ route('network') }}" class="{{ set_active(['network','mynetwork']) }}">
		@if (set_active(['network','mynetwork']))
			<img src="{{ asset('dashboard_assets/images/icon/share-grey.png') }}" alt="">
		@else
			<img src="{{ asset('dashboard_assets/images/icon/share.png') }}" alt="">
		@endif
		</a></li>
	<li><a  href="{{ route('job_home') }}" class="{{ set_active(['job_home']) }}">
		@if (set_active(['job_home']))
			<img src="{{ asset('dashboard_assets/images/icon/id-card.png') }}" alt="">
		@else
			<img src="{{ asset('dashboard_assets/images/icon/id-card-yellow.png') }}" alt="">
		@endif
		</a></li>
	<li><a href="{{ route('message') }}" class="{{ set_active(['message']) }}" >
		@if (set_active(['message']))
			<img src="{{ asset('dashboard_assets/images/icon/envelope.png') }}" alt="">
		@else
			<img src="{{ asset('dashboard_assets/images/icon/envelope-yellow.png') }}" alt="">
		@endif
		</a></li>
	<li><a href="{{ route('notification') }}" class="{{ set_active(['notification']) }}"  >
		@if (set_active(['notification']))
			<img src="{{ asset('dashboard_assets/images/icon/bell-grey.png') }}" alt="">
		@else
			<img src="{{ asset('dashboard_assets/images/icon/bell-yellow.png') }}" alt="">
		@endif
		</a></li>
</ul>