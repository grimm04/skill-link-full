<header class="header clearfix">
	<div class="navbar-sl bg-blue-dark">
		<div class="logo">
			<img src="{{ asset('dashboard_assets/images/favicon.png') }}" alt="">
		</div>
		<form action="">
			<div class="input-group">
				<span class="input-group-btn">
					<button class="btn btn-default"><img src="{{ asset('dashboard_assets/images/icon/search.png') }}" alt=""></button>
				</span>
				<input type="text" class="form-control" placeholder="Advance Search">
			</div>
		</form>
		<div class="collapse navbar-collapse navbar-ex1-collapse">
			@include('dashboard_layouts.menu')
		</div>
	</div>
</header>
