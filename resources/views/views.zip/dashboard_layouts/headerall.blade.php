<header class="header-responsive">
	<div class="container-fluid">
		<div class="logo-responsive">
			<img src="{{ asset('dashboard_assets/images/favicon.png') }}" alt="">
		</div>
		<div class="navbar-sl">
			<form action="">
				<div class="input-group">
					<span class="input-group-btn">
						<button class="btn btn-default"><img src="{{ asset('dashboard_assets/images/icon/search.png') }}" alt=""></button>
					</span>
					<input type="text" class="form-control" placeholder="Advance Search">
				</div>
			</form>
		</div>
		<ul class="nav">
			<li class="user-menu-responsive">
				<a href="#">
					<img src="{{ asset('dashboard_assets/images/2.jpg') }}" alt="">
				</a>
			</li>
			<li>
				<div>
					<a data-target="#" href="#" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
						<img src="{{ asset('dashboard_assets/images/icon/menu.png') }}" alt="">
					</a>
					<ul class="dropdown-menu right" id="ticket-list">
						<li>
							<a href="{{ route('profile_about', Auth::user()->username) }}" {{{ (Request::is('network') ? 'class=active-menu' : '') }}}>About</a>
							<a href="{{ route('profile_about', Auth::user()->username) }}" {{{ (Request::is('network') ? 'class=active-menu' : '') }}}>Timeline</a>
							<a href="{{ route('profile_about', Auth::user()->username) }}" {{{ (Request::is('network') ? 'class=active-menu' : '') }}}>Tickets</a>
							<a href="" {{{ (Request::is('network') ? 'class=active-menu' : '') }}}>Setting</a>
							<a href="{{ route('logout') }}">Logout</a>
						</li>
					</ul>
				</div>
				<div class="clearfix"></div>
			</li>
		</ul><br><br>
		<div class="navbar-sl-responsive">
			@include('dashboard_layouts.menumobile')
		</div>
		<div class="clearfix"></div>
	</div>
</header>
