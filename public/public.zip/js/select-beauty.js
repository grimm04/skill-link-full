/*================================================
=            Javascript Select Beauty            =
================================================*/

/**

	Author: Satria AJi Putra
	Created At: 25/10/17

 */


class SelectBeauty {
	constructor(data)
	{
		this.el = data.el;
		this.placeholder = data.placeholder;
		this.length = (typeof data.length !== "undefined") ? data.length : 3;
		this.max = (typeof data.max !== "undefined") ? data.max : false;
		this.tempData = {};
		this.selected = {};
		this.getTemporaryData();
		this.getHtml();
		this.hideSelect();
		this.renderView();
		this.buttonListener();
		this.toggleListener();
		this.selectListener();
	}

	// get data from select
	getTemporaryData()
	{
		let _this = this;

		$.each($(this.el).children(), function(i, r) {
			let el = $(r);
			let data = {
				text: el.text(),
				icon: el.attr('icon')
			}
			_this.tempData[el.attr('value')] = data;
		});
	}

	// hide select with add attribute multiple
	hideSelect()
	{
		$(this.el).hide();
		$(this.el).attr('multiple', true);
	}

	renderView()
	{
		$(this.el).parent().append(this.htmlBeauty);
	}

	htmlData()
	{
		let html = '';

		for(name in this.tempData) {
			html += `
				<li>
					<a href="#" data-value="${name}"><i class="iw ${this.tempData[name].icon}"></i> ${this.tempData[name].text}</a>
				</li>
			`;
		}

		return html;
	}

	getHtml()
	{
		this.htmlBeauty = `<div class="select-beauty" data-instance="${this.el}">
			<button class="btn btn-standart btn-block">${this.placeholder}</button>
			<ul class="hide">
				${this.htmlData()}
			</ul>
		</div>`;
	}

	toggleListener()
	{
		let _this = this;
		$(document).click(function(ev) {
			let el = $('[data-instance="'+_this.el+'"] ul');
			el.addClass('hide');
		});

		$('[data-instance="'+this.el+'"] ul').click(function(ev) {
			ev.stopPropagation();
		});
	}

	buttonListener()
	{
		$(document).find('[data-instance="'+this.el+'"]').on('click', 'button', function(ev) {
			ev.preventDefault();
			ev.stopPropagation();
			$(this).next('ul').toggleClass('hide');
		});
	}

	selectListener()
	{
		let _this = this;
		$(document).find('[data-instance="'+this.el+'"] ul').on('click', 'a', function(ev) {
			ev.stopPropagation();
			let el = $(this);
			let id = el.attr('data-value');
			let parent = el.parent();

			if(parent.hasClass('active')) {
				delete _this.selected[id];
				parent.removeClass('active');
			} else {
				if(_this.max && _this.countObject(_this.selected) >= _this.max) return false;
				_this.selected[id] = _this.tempData[id];
				parent.addClass('active');
			}
			_this.filter();
		});
	}

	countObject(obj)
	{
		return Object.keys(obj).length;
	}

	filter()
	{
		let arr = [];
		let btnText = [];
		let btnElement = $('[data-instance="'+this.el+'"] button');

		for(name in this.selected) {
			arr.push(name);
			btnText.push(this.selected[name].text);
		}
		
		$(this.el).val(arr);

		if(btnText.length < 1) {
			btnElement.text(this.placeholder);
		} else if(btnText.length > this.length) {
			btnElement.text("("+btnText.length+") Selected");
		} else {
			btnElement.text(btnText.join(', '));
		}
	}
}